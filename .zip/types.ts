
export interface PadData {
  id: number;
  audioUrl: string | null;
  isLooping: boolean;
  name: string | null;
}
