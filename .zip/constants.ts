
export const PAD_COUNT = 16;
