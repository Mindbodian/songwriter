import React, { useState, useEffect } from 'react';

interface AILyricHelperProps {
  isOpen: boolean;
  onClose: () => void;
  lastWord: string;
  onSelect: (line: string) => void;
}

export function AILyricHelper({ isOpen, onClose, lastWord, onSelect }: AILyricHelperProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const generateRhymingSuggestions = async () => {
    if (!lastWord) return;
    
    setIsLoading(true);
    try {
      // Generate sentences that end with the last word typed
      const templates = [
        'Through the starlight I see [word]',
        'In the darkness of the [word]',
        'As the moments pass by [word]',
        'When the feeling is so [word]',
        'Like an angel in the [word]',
        'Never thought I\'d find my [word]',
        'Always searching for that [word]',
        'In my dreams I feel the [word]',
        'Together we can share this [word]',
        'Let your spirit be my [word]'
      ];

      const mockSuggestions = templates.map(template => 
        template.replace('[word]', lastWord)
      );
      
      setSuggestions(prev => [...prev, ...mockSuggestions]);
    } catch (error) {
      console.error('Error generating suggestions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Generate initial suggestions when modal opens
  useEffect(() => {
    if (isOpen && suggestions.length === 0) {
      generateRhymingSuggestions();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg shadow-xl w-96 max-w-full max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-semibold text-white">AI Lyric Suggestions</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            ✕
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          {lastWord && (
            <div className="mb-4 text-gray-400">
              Creating lines ending with: <span className="text-white">{lastWord}</span>
            </div>
          )}
          {suggestions.length > 0 && (
            <div className="space-y-2 mb-4">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => {
                    onSelect(suggestion);
                    onClose();
                  }}
                  className="w-full text-left px-3 py-2 rounded bg-gray-700 hover:bg-gray-600 text-white transition-colors"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="p-4 border-t border-gray-700">
          <button
            onClick={generateRhymingSuggestions}
            disabled={!lastWord || isLoading}
            className="w-full px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <span className="animate-spin">⌛</span>
                Generating...
              </>
            ) : (
              <>
                <span>✨</span>
                Generate More Suggestions
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
} 