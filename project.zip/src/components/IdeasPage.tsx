import React, { useState, useEffect } from 'react';
import { Save, FilePlus, Download, X, ArrowLeft, Plus, ChevronLeft, ChevronRight } from 'lucide-react';
import { Suggestions } from './Suggestions';

interface IdeasPageProps {
  onClose: () => void;
  onImportLine: (line: string) => void;
  currentBarIndex: number;
  lastWord: string;
}

interface IdeaFile {
  name: string;
  pages: Array<{
    content: string[];
    pageNumber: number;
  }>;
}

export function IdeasPage({ onClose, onImportLine, currentBarIndex, lastWord }: IdeasPageProps) {
  const [files, setFiles] = useState<IdeaFile[]>([]);
  const [currentFile, setCurrentFile] = useState<IdeaFile | null>(null);
  const [fileName, setFileName] = useState('Untitled');
  const [currentPage, setCurrentPage] = useState(0);
  const [showSuggestions, setShowSuggestions] = useState(false);

  useEffect(() => {
    const savedIdeas = localStorage.getItem('savedIdeas');
    if (savedIdeas) {
      setFiles(JSON.parse(savedIdeas));
    }
  }, []);

  const saveToStorage = (updatedFiles: IdeaFile[]) => {
    localStorage.setItem('savedIdeas', JSON.stringify(updatedFiles));
    setFiles(updatedFiles);
  };

  const handleNew = () => {
    if (!currentFile || confirm('Start a new ideas file? Current changes will be lost.')) {
      setCurrentFile({
        name: 'Untitled',
        pages: [{ content: [''], pageNumber: 1 }]
      });
      setFileName('Untitled');
      setCurrentPage(0);
    }
  };

  const handleSave = () => {
    if (!currentFile) return;
    
    const updatedFiles = files.map(f => 
      f.name === currentFile.name ? currentFile : f
    );
    
    if (!files.find(f => f.name === currentFile.name)) {
      updatedFiles.push(currentFile);
    }
    
    saveToStorage(updatedFiles);
  };

  const handleSaveAs = () => {
    if (!currentFile) return;
    
    const newName = prompt('Enter file name:', fileName);
    if (newName) {
      const newFile = { ...currentFile, name: newName };
      setCurrentFile(newFile);
      setFileName(newName);
      
      const updatedFiles = [...files.filter(f => f.name !== newName), newFile];
      saveToStorage(updatedFiles);
    }
  };

  const handleLineChange = (index: number, content: string) => {
    if (!currentFile) return;
    
    const newPages = [...currentFile.pages];
    const currentPageContent = [...newPages[currentPage].content];
    currentPageContent[index] = content;
    
    if (index === currentPageContent.length - 1 && content !== '') {
      currentPageContent.push('');
    }
    
    newPages[currentPage] = {
      ...newPages[currentPage],
      content: currentPageContent
    };
    
    setCurrentFile({
      ...currentFile,
      pages: newPages
    });
  };

  const handleAddPage = () => {
    if (!currentFile) return;
    
    const newPages = [...currentFile.pages];
    newPages.push({
      content: [''],
      pageNumber: newPages.length + 1
    });
    
    setCurrentFile({
      ...currentFile,
      pages: newPages
    });
    setCurrentPage(newPages.length - 1);
  };

  const handlePageChange = (newPage: number) => {
    if (!currentFile) return;
    if (newPage >= 0 && newPage < currentFile.pages.length) {
      setCurrentPage(newPage);
    }
  };

  const getAllSavedLines = () => {
    return files.flatMap(file => 
      file.pages.flatMap(page => 
        page.content.filter(line => line.trim() !== '')
      )
    );
  };

  return (
    <div className="fixed inset-0 bg-blue-50 z-50">
      <div className="max-w-4xl mx-auto p-6 h-full flex flex-col">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden flex-1 flex flex-col">
          {/* Toolbar */}
          <div className="bg-gray-50 p-4 border-b flex items-center gap-4">
            <button
              onClick={onClose}
              className="flex items-center gap-2 px-3 py-1.5 bg-white border rounded-md hover:bg-gray-50 transition-colors"
            >
              <ArrowLeft size={16} />
              <span>Back</span>
            </button>
            <button
              onClick={handleNew}
              className="flex items-center gap-2 px-3 py-1.5 bg-white border rounded-md hover:bg-gray-50 transition-colors"
            >
              <FilePlus size={16} />
              <span>New</span>
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-2 px-3 py-1.5 bg-white border rounded-md hover:bg-gray-50 transition-colors"
            >
              <Save size={16} />
              <span>Save</span>
            </button>
            <button
              onClick={handleSaveAs}
              className="flex items-center gap-2 px-3 py-1.5 bg-white border rounded-md hover:bg-gray-50 transition-colors"
            >
              <Download size={16} />
              <span>Save As</span>
            </button>
            <button
              onClick={() => setShowSuggestions(!showSuggestions)}
              className="flex items-center gap-2 px-3 py-1.5 bg-white border rounded-md hover:bg-gray-50 transition-colors"
            >
              <span>Suggestions</span>
            </button>
            <span className="text-gray-500 ml-4">
              {currentFile?.name || 'Select or create a file'}
            </span>
          </div>

          <div className="flex-1 flex gap-4 p-4 overflow-hidden">
            {/* Files List */}
            <div className="w-64 bg-gray-50 rounded-lg p-4 overflow-y-auto">
              <h3 className="font-semibold mb-4">Saved Files</h3>
              {files.map((file, index) => (
                <div
                  key={index}
                  onClick={() => {
                    setCurrentFile(file);
                    setCurrentPage(0);
                  }}
                  className={`p-2 rounded-md cursor-pointer mb-2 ${
                    currentFile?.name === file.name
                      ? 'bg-blue-100'
                      : 'hover:bg-gray-100'
                  }`}
                >
                  {file.name}
                </div>
              ))}
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto">
              {currentFile ? (
                <>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 0}
                        className="p-1 rounded-md hover:bg-gray-100 disabled:opacity-50"
                      >
                        <ChevronLeft size={20} />
                      </button>
                      <span className="font-medium">
                        Page {currentPage + 1} of {currentFile.pages.length}
                      </span>
                      <button
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === currentFile.pages.length - 1}
                        className="p-1 rounded-md hover:bg-gray-100 disabled:opacity-50"
                      >
                        <ChevronRight size={20} />
                      </button>
                      <button
                        onClick={handleAddPage}
                        className="ml-4 px-3 py-1 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                      >
                        Add Page
                      </button>
                    </div>
                  </div>
                  <div className="notebook-background min-h-full p-8">
                    <div className="max-w-2xl mx-auto">
                      {currentFile.pages[currentPage].content.map((line, index) => (
                        <div key={index} className="flex items-center writing-line group">
                          <span className="text-gray-400 w-8 text-sm text-right pr-2 transform translate-y-[10px]">
                            {index + 1}
                          </span>
                          <input
                            type="text"
                            value={line}
                            onChange={(e) => handleLineChange(index, e.target.value)}
                            className="flex-1 bg-transparent border-none outline-none focus:ring-0 px-2 writing-input transform translate-y-[10px]"
                            placeholder="Enter text..."
                            maxLength={40}
                          />
                          {line && (
                            <button
                              onClick={() => onImportLine(line)}
                              className="opacity-0 group-hover:opacity-100 px-2 py-1 bg-blue-500 text-white rounded-md text-sm ml-2 transform translate-y-[10px]"
                            >
                              Import
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <div className="h-full flex items-center justify-center text-gray-500">
                  Select a file or create a new one to start
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {showSuggestions && (
        <Suggestions
          lastWord={lastWord}
          savedLines={getAllSavedLines()}
          onSelect={onImportLine}
          onClose={() => setShowSuggestions(false)}
        />
      )}
    </div>
  );
}