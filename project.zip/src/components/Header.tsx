import React from 'react';

export function Header() {
  return (
    <header className="bg-gradient-to-b from-gray-900 to-black border-b border-[#D4AF37]">
      <div className="container mx-auto px-6 py-3">
        <div className="flex items-center justify-center">
          <h1 className="text-[#D4AF37] text-2xl font-serif">
            Mindbodian Soulman Lyric Writer
          </h1>
        </div>
      </div>
    </header>
  );
}