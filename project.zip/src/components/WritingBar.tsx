import React, { KeyboardEvent, useRef, useEffect, useImperativeHandle, forwardRef } from 'react';
import { useSound } from '../hooks/useSound';

interface WritingBarProps {
  content: string;
  onChange: (content: string) => void;
  onEnter: () => void;
  isFocused?: boolean;
  onMultiLinePaste?: (lines: string[]) => void;
  onCursorPositionChange?: (position: number) => void;
  onFocus?: () => void;
  index: number;
}

export interface WritingBarRef {
  insertTextAtCursor: (text: string) => void;
  focus: () => void;
}

export const WritingBar = forwardRef<WritingBarRef, WritingBarProps>(({
  content,
  onChange,
  onEnter,
  isFocused,
  onMultiLinePaste,
  onCursorPositionChange,
  onFocus,
  index
}, ref) => {
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const playSound = useSound();
  const lastKeyPressTime = useRef<number>(0);
  const MIN_SOUND_INTERVAL = 50; // Minimum milliseconds between sounds

  useImperativeHandle(ref, () => ({
    insertTextAtCursor: (text: string) => {
      const textarea = inputRef.current;
      if (!textarea) return;

      const start = textarea.selectionStart || 0;
      const end = textarea.selectionEnd || 0;
      const newContent = content.substring(0, start) + text + content.substring(end);
      
      onChange(newContent);
      playSound('type');
      
      setTimeout(() => {
        if (textarea) {
          textarea.focus();
          const newPosition = start + text.length;
          textarea.setSelectionRange(newPosition, newPosition);
        }
      }, 0);
    },
    focus: () => {
      inputRef.current?.focus();
    }
  }));

  useEffect(() => {
    if (isFocused && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isFocused]);

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    const now = Date.now();
    
    // Play typing sound with rate limiting
    if (now - lastKeyPressTime.current >= MIN_SOUND_INTERVAL) {
      playSound('type');
      lastKeyPressTime.current = now;
    }

    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      playSound('enter');
      onEnter();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedText = e.clipboardData.getData('text');
    const lines = pastedText.split(/\r?\n/).filter(line => line.trim() !== '');
    
    if (lines.length > 1 && onMultiLinePaste) {
      onMultiLinePaste(lines);
    } else {
      const textarea = inputRef.current;
      if (!textarea) return;

      const start = textarea.selectionStart || 0;
      const end = textarea.selectionEnd || 0;
      const newContent = content.substring(0, start) + lines[0] + content.substring(end);
      
      onChange(newContent);
      playSound('type');
      
      setTimeout(() => {
        if (textarea) {
          const newPosition = start + lines[0].length;
          textarea.setSelectionRange(newPosition, newPosition);
        }
      }, 0);
    }
  };

  const handleSelect = (e: React.SyntheticEvent<HTMLTextAreaElement>) => {
    const textarea = e.target as HTMLTextAreaElement;
    if (onCursorPositionChange) {
      onCursorPositionChange(textarea.selectionStart);
    }
  };

  const handleFocus = () => {
    if (onFocus) {
      onFocus();
    }
  };

  return (
    <div className="writing-line">
      <textarea
        ref={inputRef}
        value={content}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        onPaste={handlePaste}
        onSelect={handleSelect}
        onClick={handleSelect}
        onFocus={handleFocus}
        className="writing-input bg-transparent border-none outline-none focus:ring-0 w-full"
        placeholder="Enter text..."
        rows={1}
      />
    </div>
  );
});

WritingBar.displayName = 'WritingBar';