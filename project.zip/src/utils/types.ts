export interface RhymeWord {
  word: string;
  score: number;
  numSyllables?: number;
}